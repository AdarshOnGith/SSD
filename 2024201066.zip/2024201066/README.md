
*********** Required things to check before running script ************

access and power_levels should be present in same directory where script files 2024201066_q1.sh and 2024201066_q2.sh are present which is "2024201066"

******************* Description of Scripts ******************
2024201066_q1.sh
INPUT : access.log file
OUTPUT : lines which has POST call with 404 status


2024201066_q2.sh
INPUT : power_levels.txt file
OUTPUT : sum of all powers


********* STEPS TO RUN SCRIPT FILE **************

open terminal
navigate to directory "2024201066"
now run the script files as below-
./2024201066_q1.sh
./2024201066_q2.sh
